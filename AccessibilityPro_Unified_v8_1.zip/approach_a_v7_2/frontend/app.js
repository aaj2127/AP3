document.addEventListener('DOMContentLoaded', () => {
  const statsEl = document.querySelector('.stats-grid');
  const leadsEl = document.querySelector('.leads-panel');
  fetch('http://localhost:5000/api/kpis').then(r => r.json()).then(data => {
    statsEl.innerHTML = `
      <div class="stat-card"><div class="stat-value">${data.total}</div><div class="stat-label">Total Leads</div></div>
      <div class="stat-card"><div class="stat-value">$${data.value_usd/1000}K</div><div class="stat-label">Est. Value</div></div>
      <div class="stat-card"><div class="stat-value">${data.avg_score}</div><div class="stat-label">Avg Score</div></div>`;
  });
  fetch('http://localhost:5000/api/prospects').then(r => r.json()).then(prospects => {
    const cards = prospects.map(p => `
      <article class="lead-card">
        <div class="lead-header"><h3 class="lead-title">${p.name}</h3><span class="lead-score">${p.score}/100</span></div>
        <div class="lead-details">
          <div class="lead-detail"><span class="fas fa-globe"></span><a href="${p.url}">${p.url}</a></div>
          <div class="lead-detail"><span class="fas fa-industry"></span>${p.industry}</div>
          <div class="lead-detail"><span class="fas fa-map-marker-alt"></span>${p.location}</div>
          <div class="lead-detail"><span class="fas fa-dollar-sign"></span>Est. Value: $${p.est_value}</div>
        </div>
        <div class="issues"><strong>Top issues</strong><ul>${p.issues.map(i=>`<li>${i}</li>`).join('')}</ul></div>
        <div class="actions">
          <button type="button" class="btn-action"><span class="fas fa-search"></span> Analyze</button>
          <button type="button" class="btn-action primary"><span class="fas fa-envelope"></span> Email</button>
          <button type="button" class="btn-action"><span class="fas fa-star"></span> Add to Leads</button>
        </div>
      </article>`).join('');
    leadsEl.insertAdjacentHTML('beforeend', cards);
  });
});