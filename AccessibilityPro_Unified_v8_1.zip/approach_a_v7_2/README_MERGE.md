
# AccessibilityPro — Merged v7 (Backend + Frontend)

This package merges your Flask backend with the AccessibilityPro front-end tokens and demo UI.

## Structure
- `backend/` — your original codebase (Flask API, audit logic, PDF, email). Original `web/` moved to `backend/web_legacy/` for reference.
- `frontend/` — AccessibilityPro UI (tokens, demo HTML with proper landmarks/focus, PDFs, branding). Open `frontend/index.html`.

## Run (Dev)
1) Backend
   ```bash
   cd backend
   python3 -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt
   export FLASK_APP=src/server.py
   export FLASK_ENV=development
   flask run --port 5000
   ```
2) Frontend
   - Open `frontend/index.html` directly, or serve it:
   ```bash
   cd frontend
   python3 -m http.server 5173
   ```

## API Expectations
- `GET /api/kpis` → `{ "total": n, "value_usd": n, "avg_score": n }`
- `GET /api/prospects` → `[{ name, url, industry, location, est_value, score, issues:[] }]`
- `POST /api/report` → returns a non-tagged PDF (ReportLab)
- `POST /api/email` → queues/sends email; gate behind approval flag

## Theming
- Front-end uses `frontend/tokens.css` | `tokens.json`.
- For the legacy UI in `backend/web_legacy/`, you can include `<link rel="stylesheet" href="../../frontend/tokens.css">` to align styles.

## Notes
- PDF/UA: The current ReportLab path is non-tagged (good for drafts). Keep claims clear: conformance assistance, *not* automated compliance.
- Security: add an API key header for `/api/report` and `/api/email` in production.
