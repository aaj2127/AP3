
import os, time, requests
USER_AGENT = os.environ.get("AAAT_USER_AGENT", "AAAT/portal/0.1")
TIMEOUT = float(os.environ.get("AAAT_TIMEOUT", 12))
RETRIES = int(os.environ.get("AAAT_RETRIES", 1))

def fetch(url: str) -> requests.Response:
    last = None
    for i in range(RETRIES+1):
        try:
            return requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=TIMEOUT)
        except Exception as e:
            last = e
            time.sleep(0.5*(i+1))
    raise last
