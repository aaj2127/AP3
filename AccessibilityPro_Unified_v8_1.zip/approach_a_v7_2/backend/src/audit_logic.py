
from bs4 import BeautifulSoup
from .utils import fetch

def _issue(rule, severity, message):
    return {"rule": rule, "severity": severity, "message": message, "wcag": {}}

def audit_url(url: str):
    res = {"url": url, "status": "ok", "http": {}, "issues": [], "summary": {"errors":0, "warnings":0, "passes":0}}
    try:
        r = fetch(url)
        res["http"] = {"status_code": r.status_code, "content_type": r.headers.get("Content-Type", "")}
        if r.status_code >= 400:
            res["status"] = "http_error"; res["summary"]["errors"] += 1
            res["issues"].append(_issue("http", "error", f"HTTP {r.status_code}"))
            return res
        soup = BeautifulSoup(r.text, 'lxml')
        # title
        t = soup.title.string.strip() if soup.title and soup.title.string else ''
        if not t:
            res["issues"].append(_issue("title","error","Missing <title>")); res["summary"]["errors"]+=1
        else:
            res["summary"]["passes"]+=1
        # lang
        html = soup.find('html')
        lang = html.get('lang','').strip().lower() if html else ''
        if not lang:
            res["issues"].append(_issue("lang","error","Missing <html lang>")); res["summary"]["errors"]+=1
        else:
            res["summary"]["passes"]+=1
        # empty links
        for a in soup.find_all('a'):
            if not (a.get_text() or '').strip():
                res["issues"].append(_issue("links","error","Link without accessible name")); res["summary"]["errors"]+=1
        if res['summary']['errors']==0 and res['summary']['warnings']==0:
            res['status'] = 'pass'
        return res
    except Exception as e:
        res["status"] = "exception"; res["summary"]["errors"]+=1
        res["issues"].append(_issue("exception","error", f"{type(e).__name__}: {e}"))
        return res
