
import os, smtplib, ssl
from email.message import EmailMessage

def send_email(subject: str, body: str, attachments=None):
    attachments = attachments or []
    host = os.getenv('SMTP_HOST'); port = int(os.getenv('SMTP_PORT','465'))
    user = os.getenv('SMTP_USER'); password = os.getenv('SMTP_PASS')
    use_ssl = os.getenv('SMTP_SSL','1')=='1'
    from_email = os.getenv('FROM_EMAIL'); to_email = os.getenv('TO_EMAIL')
    if not (host and user and password and from_email and to_email):
        print('SMTP not fully configured; skipping send.'); return
    msg = EmailMessage(); msg['Subject']=subject; msg['From']=from_email; msg['To']=to_email; msg.set_content(body)
    for p in attachments:
        try:
            with open(p,'rb') as f: data=f.read()
            msg.add_attachment(data, maintype='application', subtype='octet-stream', filename=os.path.basename(p))
        except Exception as e:
            print('Attachment failed', p, e)
    if use_ssl:
        with smtplib.SMTP_SSL(host, port, context=ssl.create_default_context()) as s:
            s.login(user,password); s.send_message(msg)
    else:
        with smtplib.SMTP(host, port) as s:
            s.starttls(); s.login(user,password); s.send_message(msg)
