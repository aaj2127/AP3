
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import cm
from reportlab.lib import colors
import os, json

def _header(c, title):
    # Try theme color
    col = '#1f2937'
    try:
        theme_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'theme', 'theme.json')
        with open(theme_path, 'r', encoding='utf-8') as f:
            col = json.load(f)['colors']['panel']
    except Exception:
        pass
    c.setFillColor(colors.HexColor(col))
    c.setFont('Helvetica-Bold', 16)
    c.drawString(2*cm, 28*cm, title)
    c.setFillColor(colors.black)

def generate_pdf(path, results):
    c = canvas.Canvas(path, pagesize=A4)
    w, h = A4
    _header(c, 'Accessibility Audit Report')
    y = 26.8*cm
    total_err = sum(r['summary']['errors'] for r in results)
    total_warn = sum(r['summary']['warnings'] for r in results)
    total_pass = sum(r['summary']['passes'] for r in results)
    c.setFont('Helvetica', 12)
    c.drawString(2*cm, y, f'Total URLs: {len(results)} | Errors: {total_err} | Warnings: {total_warn} | Passes: {total_pass}')
    y -= 1*cm
    for r in results:
        c.setFont('Helvetica-Bold', 12); c.drawString(2*cm, y, r.get('url','(unknown)')); y -= 0.6*cm
        s = r['summary']; c.setFont('Helvetica', 10)
        c.drawString(2*cm, y, f"errors={s['errors']} warnings={s['warnings']} passes={s['passes']} status={r['status']}")
        y -= 0.5*cm
        for issue in r.get('issues',[])[:8]:
            msg = f"- [{issue['severity']}] {issue['rule']} — {issue['message']}"
            c.drawString(2.5*cm, y, msg[:95]); y -= 0.45*cm
            if y < 3*cm: c.showPage(); _header(c, 'Accessibility Audit Report'); y = 26*cm
        y -= 0.4*cm
        if y < 4*cm: c.showPage(); _header(c, 'Accessibility Audit Report'); y = 26*cm
    c.showPage(); c.save()
