
import argparse, json, os, csv
from .audit_logic import audit_url
from .report_pdf import generate_pdf

def cmd_audit(a):
    r = audit_url(a.url)
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    with open(a.out,'w',encoding='utf-8') as f: json.dump(r,f,indent=2)
    if a.csv:
        with open(a.csv,'w',newline='',encoding='utf-8') as f:
            w=csv.writer(f); s=r['summary']; w.writerow(['url','errors','warnings','passes','status']); w.writerow([r['url'],s['errors'],s['warnings'],s['passes'],r['status']])
    print('Done:', r['url'])

def cmd_report(a):
    with open(a.input,'r',encoding='utf-8') as f: data=json.load(f)
    res = data['results'] if 'results' in data else [data]
    os.makedirs(os.path.dirname(a.pdf), exist_ok=True)
    generate_pdf(a.pdf, res); print('PDF:', a.pdf)

def main(argv=None):
    p=argparse.ArgumentParser(); sub=p.add_subparsers(dest='cmd',required=True)
    pa=sub.add_parser('audit'); pa.add_argument('url'); pa.add_argument('--out',default='out/audit.json'); pa.add_argument('--csv',default=''); pa.set_defaults(func=cmd_audit)
    pr=sub.add_parser('report'); pr.add_argument('--in',dest='input',required=True); pr.add_argument('--pdf',default='out/report.pdf'); pr.set_defaults(func=cmd_report)
    a=p.parse_args(argv); a.func(a)
if __name__=='__main__': main()
