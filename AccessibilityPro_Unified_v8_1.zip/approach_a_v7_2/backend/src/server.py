
import os, json
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from datetime import datetime
from .audit_logic import audit_url
from .report_pdf import generate_pdf
from .email_automation import send_email

app = Flask(__name__); CORS(app)
BASE = os.path.dirname(os.path.dirname(__file__))
OUT_DIR = os.path.join(BASE, 'out'); DATA_DIR = os.path.join(BASE, 'data')
os.makedirs(OUT_DIR, exist_ok=True); os.makedirs(DATA_DIR, exist_ok=True)
SEEDS = os.path.join(DATA_DIR,'seeds.txt')
if not os.path.exists(SEEDS):
    with open(SEEDS,'w',encoding='utf-8') as f: f.write('https://example.com
')

def _score(s): return max(0, min(100, 100 - (s.get('errors',0)*3 + s.get('warnings',0))))

def _value(url, industry):
    base=3000
    if (industry or '').lower() in ('healthcare','education','finance','government','legal'): base+=2500
    if len(url)>20: base+=300
    return base

@app.post('/api/prospects')
def prospects():
    d=request.json or {}; industry=d.get('industry','general'); location=d.get('location','Local'); size=d.get('size','Small'); n=int(d.get('batch_size',5))
    with open(SEEDS,'r',encoding='utf-8') as f: seeds=[x.strip() for x in f if x.strip() and not x.startswith('#')]
    if not seeds: seeds=['https://example.com']
    out=[]
    for url in seeds[:n]:
        a=audit_url(url); s=a['summary']
        name=url.split('//')[-1].split('/')[0].replace('www.','').split('.')[0].title()
        out.append({ 'name': name or 'Prospect','website':url,'industry':industry,'location':location,'size':size,'est_value':_value(url,industry),'score':_score(s),'summary':s })
    return jsonify({'prospects': out})

@app.post('/api/audit')
def api_audit():
    d=request.json or {}; url=d.get('url');
    if not url: return jsonify({'error':'url required'}), 400
    return jsonify(audit_url(url))

@app.post('/api/report')
def api_report():
    d=request.json or {}; results=d.get('results'); url=d.get('url')
    if not results:
        if not url: return jsonify({'error':'Provide results[] or url'}), 400
        results=[audit_url(url)]
    ts=datetime.utcnow().strftime('%Y%m%d_%H%M%S'); pdf=os.path.join(OUT_DIR, f'report_{ts}.pdf')
    generate_pdf(pdf, results)
    return jsonify({'pdf': os.path.basename(pdf)})

@app.get('/api/report/<name>')
def get_pdf(name):
    path=os.path.join(OUT_DIR,name)
    if not os.path.exists(path): return jsonify({'error':'not found'}),404
    return send_file(path, mimetype='application/pdf', as_attachment=True, download_name=name)

@app.post('/api/email')
def api_email():
    d=request.json or {}; subj=d.get('subject','Accessibility Audit Results'); body=d.get('body','See attached report.'); pdf=d.get('pdf');
    paths=[os.path.join(OUT_DIR,pdf)] if pdf else []
    send_email(subj, body, paths)
    return jsonify({'status':'sent_or_skipped'})

if __name__=='__main__': app.run(host='127.0.0.1', port=5050, debug=True)
