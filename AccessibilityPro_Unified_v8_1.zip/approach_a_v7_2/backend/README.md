
# ADHD-Friendly Accessibility Audit Tool (Portal)

**Generated:** 2025-09-19T16:23:05.820777Z

- Web dashboard in `web/` (Figure‑8 style)
- API server: `python -m src.server` (port 5050)
- CLI samples: `python -m src.cli_tool audit https://example.com --out out/audit.json`
