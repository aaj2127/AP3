
(async function(){
  const api = (p)=> (window.API_BASE || '') + p;
  const qs = (s, el=document)=> el.querySelector(s);
  const qsa = (s, el=document)=> Array.from(el.querySelectorAll(s));

  // Insert KPI numbers if we find a 3-card stats grid
  async function loadKPIs(){
    try{
      const res = await fetch(api('/api/kpis'));
      if(!res.ok) return;
      const data = await res.json();
      const cards = qsa('.stats-grid .stat-card .stat-value');
      if(cards.length >= 3){
        if(typeof data.total !== 'undefined') cards[0].textContent = String(data.total);
        if(typeof data.value_usd !== 'undefined') cards[1].textContent = Intl.NumberFormat('en-US', {style:'currency', currency:'USD', maximumFractionDigits:0}).format(data.value_usd);
        if(typeof data.avg_score !== 'undefined') cards[2].textContent = String(data.avg_score);
      }
    }catch(e){ console.warn('KPIs fetch error', e); }
  }

  // Render prospects list if an element with .leads-panel exists
  async function loadProspects(){
    try{
      const res = await fetch(api('/api/prospects'));
      if(!res.ok) return;
      const items = await res.json();
      const panel = qs('.leads-panel');
      if(!panel) return;

      // Remove existing article cards (demo placeholders)
      qsa('article.lead-card', panel).forEach(n=>n.remove());

      items.forEach((p, i)=>{
        const card = document.createElement('article');
        card.className = 'lead-card';
        card.setAttribute('aria-labelledby', `lead-${i+1}-title`);
        card.innerHTML = `
          <div class="lead-header">
            <h3 id="lead-${i+1}-title" class="lead-title">${p.name || 'Unknown'}</h3>
            <span class="lead-score">${(p.score ?? 0)}/100</span>
          </div>
          <div class="lead-details">
            <div class="lead-detail"><span class="fas fa-globe" aria-hidden="true"></span><a href="${p.url || '#'}">${(p.url || '').replace(/^https?:\/\//,'')}</a></div>
            <div class="lead-detail"><span class="fas fa-industry" aria-hidden="true"></span>${p.industry || ''}</div>
            <div class="lead-detail"><span class="fas fa-map-marker-alt" aria-hidden="true"></span>${p.location || ''}</div>
            <div class="lead-detail"><span class="fas fa-dollar-sign" aria-hidden="true"></span>Est. Value: ${p.est_value ? Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:0}).format(p.est_value) : '-'}</div>
          </div>
          <div class="issues" aria-label="Top issues">
            <strong>Top issues</strong>
            <ul>${(p.issues || []).slice(0,3).map(x=>`<li>${x}</li>`).join('') || '<li>No data</li>'}</ul>
          </div>
          <div class="actions">
            <button type="button" class="btn-action"><span class="fas fa-search" aria-hidden="true"></span> Analyze</button>
            <button type="button" class="btn-action primary"><span class="fas fa-envelope" aria-hidden="true"></span> Email</button>
            <button type="button" class="btn-action"><span class="fas fa-star" aria-hidden="true"></span> Add to Leads</button>
          </div>
        `;
        panel.appendChild(card);
      });
    }catch(e){ console.warn('Prospects fetch error', e); }
  }

  // Run
  await loadKPIs();
  await loadProspects();
})();


// Report + Email button wiring
document.addEventListener('click', async e => {
  const btn = e.target.closest('.btn-primary, .btn-secondary');
  if (!btn) return;
  const isReport = btn.classList.contains('btn-primary');
  try {
    btn.disabled = true;
    btn.textContent = isReport ? 'Generating…' : 'Sending…';
    const res = await fetch(window.API_BASE + (isReport?'/api/report':'/api/email'), {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ demo: true })
    });
    if(!res.ok) throw new Error(await res.text());
    alert((isReport?'Report':'Email')+' request sent!');
  } catch(err){
    alert('Error: '+err.message);
  } finally {
    btn.disabled = false;
    btn.textContent = isReport ? 'Generate PDF Reports' : 'Generate Personalized Emails';
  }
});


  function toast(msg, ok=true){
    const c = document.getElementById('toast');
    if(!c) return alert(msg);
    const el = document.createElement('div');
    el.style.background = ok ? '#ECFDF5' : '#FEF2F2';
    el.style.border = '1px solid ' + (ok ? '#059669' : '#DC2626');
    el.style.color = ok ? '#065F46' : '#7F1D1D';
    el.style.padding = '12px 14px';
    el.style.borderRadius = '10px';
    el.style.marginTop = '8px';
    el.style.boxShadow = '0 2px 8px rgba(0,0,0,0.08)';
    el.textContent = msg;
    c.appendChild(el);
    setTimeout(()=>{ el.remove(); }, 3500);
  }

  async function postReport(payload){
    try{
      toast('Generating report…');
      const res = await fetch(api('/api/report'), {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify(payload || {style: qs('#report-style')?.value || 'executive'})
      });
      if(!res.ok) throw new Error('Report failed: ' + res.status);
      const blob = await res.blob();
      // Optimistic download for demo; backend returns application/pdf
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = 'AccessibilityPro_Report.pdf';
      document.body.appendChild(a); a.click(); a.remove();
      toast('Report ready — downloaded.' , true);
    }catch(e){
      console.warn(e); toast('Report error: ' + e.message, false);
    }
  }

  async function postEmail(payload){
    try{
      toast('Queuing outreach emails…');
      const res = await fetch(api('/api/email'), {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify(payload || {
          template: 'Professional Audit Offer',
          from_name: qs('#your-name')?.value || 'AccessibilityPro',
          from_email: qs('#your-email')?.value || 'contact@accessibilitypro.com',
          rate_per_hour: Number(qs('#consulting-rate')?.value || 150)
        })
      });
      if(!res.ok) throw new Error('Email failed: ' + res.status);
      const data = await res.json().catch(()=>({ok:true}));
      toast('Emails queued for sending.' , true);
    }catch(e){
      console.warn(e); toast('Email error: ' + e.message, false);
    }
  }

  // Wire buttons
  window.addEventListener('DOMContentLoaded', ()=>{
    const btnPdf = qs('#btn-generate-pdf');
    const btnEmail = qs('#btn-generate-emails');
    if(btnPdf) btnPdf.addEventListener('click', ()=> postReport());
    if(btnEmail) btnEmail.addEventListener('click', ()=> postEmail());
  });

// Backend switcher
window.addEventListener('DOMContentLoaded', ()=>{
  const sel = document.getElementById('backend-select');
  if(sel){
    sel.addEventListener('change', ()=>{
      window.API_BASE = sel.value;
      console.log('Switched backend to', window.API_BASE);
      // refresh KPIs and Prospects
      location.reload();
    });
  }
});


  // Backend selector: stores choice and updates API_BASE.
  function setupBackendToggle(){
    const sel = document.getElementById('api-backend-select');
    if(!sel) return;
    // Restore previous selection
    const saved = localStorage.getItem('ACCESSIBILITYPRO_BACKEND') || '';
    if(saved === 'B'){ sel.value = 'B'; window.API_BASE = (window.API_B_URL || 'http://localhost:5001'); }
    else { sel.value = ''; window.API_BASE = (window.API_A_URL || 'http://localhost:5000'); }
    // Re-load data based on current selection
    loadKPIs(); loadProspects();
    sel.addEventListener('change', ()=>{
      const useB = sel.value === 'B';
      localStorage.setItem('ACCESSIBILITYPRO_BACKEND', useB ? 'B' : 'A');
      window.API_BASE = useB ? (window.API_B_URL || 'http://localhost:5001') : (window.API_A_URL || 'http://localhost:5000');
      // Reload data for new backend
      loadKPIs(); loadProspects();
      toast(`Switched to ${useB ? 'Approach B' : 'Approach A'}.`, true);
    });
  }
  // Expose loaders so the toggle can call them
  window.loadKPIs = loadKPIs;
  window.loadProspects = loadProspects;

  // Initialize after DOM
  window.addEventListener('DOMContentLoaded', setupBackendToggle);
