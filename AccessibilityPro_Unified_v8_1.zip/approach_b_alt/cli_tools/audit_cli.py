# CLI tool for running WCAG audits
print('Running WCAG audit...')
