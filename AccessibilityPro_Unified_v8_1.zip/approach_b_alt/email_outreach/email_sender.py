# Script to send outreach emails
print('Sending emails...')
