
# AccessibilityPro — Unified Merge v8

This package contains both implementations:
- **Approach A (backend_a + frontend)** — Flask API + AccessibilityPro front-end (tokens, accessible demo, /api wired for KPIs, prospects, report, email).
- **Approach B (backend_b)** — Alternate approach you provided (kept intact).

## Choose an approach
### Run Approach A
```bash
cd backend_a
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export FLASK_APP=src/server.py
flask run --port 5000
```
Front-end:
```bash
cd ../frontend
python3 -m http.server 5173
# In demo_html/prospecting_demo_accessible.html set:
# window.API_BASE = "http://localhost:5000"
```

### Run Approach B
Check `backend_b/README*` or `requirements*.txt`. If Flask-based, run similarly:
```bash
cd backend_b
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
# start script may vary: app.py / main.py / server.py
python app.py  # or equivalent
```
To reuse the same front-end, serve `frontend/` and point `window.API_BASE` to Approach B's URL.

## Notes
- **PDF exports:** Approach A uses ReportLab (draft PDFs, non-tagged). For PDF/UA, route a separate export path to a tagging pipeline.
- **Tokens & Accessibility:** The front-end uses `tokens.css` and includes visible focus, reduced-motion guard, tabular numerals, and landmark roles.
- **Legacy assets:** Kept at `backend_a/web_legacy` (from your earlier project).

## Security & production
- Add API keys/auth for `/api/report` and `/api/email`.
- Rate-limit scan/report endpoints.
- Do not claim "automated compliance"—this provides conformance assistance; human verification required for critical issues.
